--
-- PostgreSQL database dump
--

-- Dumped from database version 15.11 (Debian 15.11-1.pgdg120+1)
-- Dumped by pg_dump version 17.2 (Debian 17.2-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alerts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alerts (
    id integer NOT NULL,
    user_id integer,
    user_currency_id integer,
    threshold numeric(18,8) NOT NULL,
    condition_type character varying(50) DEFAULT 'above'::character varying NOT NULL,
    currency_type character varying(10) DEFAULT 'USD'::character varying NOT NULL,
    is_active boolean,
    last_triggered_at timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    CONSTRAINT check_alert_has_condition CHECK ((threshold IS NOT NULL))
);


ALTER TABLE public.alerts OWNER TO postgres;

--
-- Name: alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.alerts_id_seq OWNER TO postgres;

--
-- Name: alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.alerts_id_seq OWNED BY public.alerts.id;


--
-- Name: crypto_rates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.crypto_rates (
    id bigint NOT NULL,
    currency character varying NOT NULL,
    price numeric(18,8) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.crypto_rates OWNER TO postgres;

--
-- Name: crypto_rates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.crypto_rates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.crypto_rates_id_seq OWNER TO postgres;

--
-- Name: crypto_rates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.crypto_rates_id_seq OWNED BY public.crypto_rates.id;


--
-- Name: dollar_rates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dollar_rates (
    id bigint NOT NULL,
    price numeric(18,8) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    CONSTRAINT check_id_is_one CHECK ((id = 1))
);


ALTER TABLE public.dollar_rates OWNER TO postgres;

--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscriptions (
    id bigint NOT NULL,
    user_id bigint,
    plan character varying,
    expires_at timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.subscriptions OWNER TO postgres;

--
-- Name: subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.subscriptions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.subscriptions_id_seq OWNER TO postgres;

--
-- Name: subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.subscriptions_id_seq OWNED BY public.subscriptions.id;


--
-- Name: user_currencies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_currencies (
    id bigint NOT NULL,
    user_id bigint,
    currency character varying NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.user_currencies OWNER TO postgres;

--
-- Name: user_currencies_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_currencies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_currencies_id_seq OWNER TO postgres;

--
-- Name: user_currencies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_currencies_id_seq OWNED BY public.user_currencies.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    telegram_id bigint NOT NULL,
    username character varying(70),
    language character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: alerts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts ALTER COLUMN id SET DEFAULT nextval('public.alerts_id_seq'::regclass);


--
-- Name: crypto_rates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crypto_rates ALTER COLUMN id SET DEFAULT nextval('public.crypto_rates_id_seq'::regclass);


--
-- Name: subscriptions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions ALTER COLUMN id SET DEFAULT nextval('public.subscriptions_id_seq'::regclass);


--
-- Name: user_currencies id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_currencies ALTER COLUMN id SET DEFAULT nextval('public.user_currencies_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alerts (id, user_id, user_currency_id, threshold, condition_type, currency_type, is_active, last_triggered_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: crypto_rates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.crypto_rates (id, currency, price, created_at, updated_at) FROM stdin;
1	BTC	96090.69000000	2025-02-17 10:52:20.384197	2025-02-17 10:52:20.384205
2	ETH	2754.79000000	2025-02-17 10:52:20.38804	2025-02-17 10:52:20.388041
3	TON	3.82500000	2025-02-17 10:52:20.38917	2025-02-17 10:52:20.389171
4	NOT	0.00303100	2025-02-17 10:52:20.390147	2025-02-17 10:52:20.390148
5	DOGE	0.26267000	2025-02-17 10:52:20.391299	2025-02-17 10:52:20.391301
6	CATI	0.16450000	2025-02-17 10:52:20.392262	2025-02-17 10:52:20.392262
7	XRP	2.67970000	2025-02-17 10:52:20.393217	2025-02-17 10:52:20.393218
8	SOL	183.86000000	2025-02-17 10:52:20.394148	2025-02-17 10:52:20.394148
9	BNB	666.12000000	2025-02-17 10:52:20.395555	2025-02-17 10:52:20.395557
10	MATIC	0.37940000	2025-02-17 10:52:20.39731	2025-02-17 10:52:20.397311
11	ADA	0.79590000	2025-02-17 10:52:20.399204	2025-02-17 10:52:20.399205
12	TRX	0.24610000	2025-02-17 10:52:20.400895	2025-02-17 10:52:20.400897
13	AVAX	25.33000000	2025-02-17 10:52:20.402826	2025-02-17 10:52:20.402827
14	SUI	3.28390000	2025-02-17 10:52:20.404267	2025-02-17 10:52:20.404269
15	LINK	19.36000000	2025-02-17 10:52:20.405511	2025-02-17 10:52:20.405511
16	DOT	4.94600000	2025-02-17 10:52:20.40729	2025-02-17 10:52:20.407291
17	BCH	327.90000000	2025-02-17 10:52:20.408639	2025-02-17 10:52:20.40864
18	LTC	124.36000000	2025-02-17 10:52:20.410582	2025-02-17 10:52:20.410583
19	WBETH	2925.28000000	2025-02-17 10:52:20.413817	2025-02-17 10:52:20.413825
20	RNDR	7.03000000	2025-02-17 10:52:20.41803	2025-02-17 10:52:20.418039
21	ICP	7.14500000	2025-02-17 10:52:20.422106	2025-02-17 10:52:20.42211
22	UNI	9.95800000	2025-02-17 10:52:20.42731	2025-02-17 10:52:20.427312
23	THETA	1.34900000	2025-02-17 10:52:20.431443	2025-02-17 10:52:20.431447
24	XLM	0.34050000	2025-02-17 10:52:20.435657	2025-02-17 10:52:20.435659
25	AAVE	269.27000000	2025-02-17 10:52:20.437287	2025-02-17 10:52:20.437289
26	ATOM	4.87100000	2025-02-17 10:52:20.438408	2025-02-17 10:52:20.438409
27	APT	6.01000000	2025-02-17 10:52:20.439403	2025-02-17 10:52:20.439404
28	ARB	0.49130000	2025-02-17 10:52:20.440293	2025-02-17 10:52:20.440293
29	OM	7.42660000	2025-02-17 10:52:20.441166	2025-02-17 10:52:20.441167
30	TRUMP	17.60000000	2025-02-17 10:52:20.441962	2025-02-17 10:52:20.441963
\.


--
-- Data for Name: dollar_rates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dollar_rates (id, price, created_at, updated_at) FROM stdin;
1	91.62545200	2025-02-17 10:52:03.151081	2025-02-17 10:52:03.151084
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscriptions (id, user_id, plan, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_currencies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_currencies (id, user_id, currency, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, telegram_id, username, language, created_at, updated_at) FROM stdin;
\.


--
-- Name: alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.alerts_id_seq', 1, false);


--
-- Name: crypto_rates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.crypto_rates_id_seq', 30, true);


--
-- Name: subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.subscriptions_id_seq', 1, false);


--
-- Name: user_currencies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_currencies_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: crypto_rates crypto_rates_currency_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crypto_rates
    ADD CONSTRAINT crypto_rates_currency_key UNIQUE (currency);


--
-- Name: crypto_rates crypto_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crypto_rates
    ADD CONSTRAINT crypto_rates_pkey PRIMARY KEY (id);


--
-- Name: dollar_rates dollar_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dollar_rates
    ADD CONSTRAINT dollar_rates_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: user_currencies uix_user_currency; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_currencies
    ADD CONSTRAINT uix_user_currency UNIQUE (user_id, currency);


--
-- Name: alerts uix_user_currency_alert_type; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT uix_user_currency_alert_type UNIQUE (user_id, user_currency_id, condition_type, currency_type);


--
-- Name: user_currencies user_currencies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_currencies
    ADD CONSTRAINT user_currencies_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_telegram_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_telegram_id_key UNIQUE (telegram_id);


--
-- Name: alerts alerts_user_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_user_currency_id_fkey FOREIGN KEY (user_currency_id) REFERENCES public.user_currencies(id) ON DELETE CASCADE;


--
-- Name: alerts alerts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_currencies user_currencies_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_currencies
    ADD CONSTRAINT user_currencies_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

